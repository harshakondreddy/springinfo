# SpringInfo Privacy Policy

Last updated: 2026-06-29

SpringInfo is designed to display Eureka instance information inline on `/registry` pages.

## Data collection and usage

- SpringInfo does not collect, sell, or transfer personal data to third parties.
- SpringInfo does not use analytics, ad tracking, or remote code execution.
- SpringInfo stores user preferences locally using Chrome sync storage:
  - request timeout
  - info auto-close delay
  - fallback mode
  - table visibility toggles
  - diagnostics toggle

## Network access

- SpringInfo reads existing Eureka status links and requests info endpoints needed to render inline results.
- Requests are made from the browser to target service endpoints required for extension functionality.

## Diagnostics mode

- Diagnostics mode is optional and disabled by default.
- If enabled, the user can click `Copy Debug` to copy a troubleshooting payload to clipboard.
- Debug payload is redacted and includes origin+path only for URLs (no query parameters).
- Debug payload stays local unless the user manually shares it.

## Security

- External links open with `rel="noreferrer noopener"`.
- No `eval` usage and no dynamic remote scripts.

## Contact

For support, use the contact/support link provided in the Chrome Web Store listing.
